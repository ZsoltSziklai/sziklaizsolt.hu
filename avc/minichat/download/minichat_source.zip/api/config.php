<?php
// MiniChat — közös konfiguráció, PDO kapcsolat, session és JSON helperek.
// PHP 7.3 kompatibilis (nincs typed property, nincs match).

declare(strict_types=1);

mb_internal_encoding('UTF-8');

ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

define('DB_HOST',    'localhost');
define('DB_PORT',    3306);
define('DB_NAME', 'YOUR_DATABASE_HERE');
define('DB_USER', 'YOUR_DB_USER_HERE');
define('DB_PASS', 'YOUR_PASSWORD_HERE');
define('DB_CHARSET', 'utf8mb4');

// DB reset token — csak az init_db.php?reset=1&secret=... végpontot védi.
// Publikus repo-ban is OK: nem hitelesítés-megkerülés, csupán a teszt-reset kapu.
define('ADMIN_SECRET', 'advc-test-reset-2026');

function db(): PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }
    $dsn = sprintf(
        'mysql:host=%s;port=%d;dbname=%s;charset=%s',
        DB_HOST, DB_PORT, DB_NAME, DB_CHARSET
    );
    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ]);
    return $pdo;
}

function session_boot(): void {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    ini_set('session.cookie_httponly', '1');
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    if (!empty($_SERVER['HTTPS'])) {
        ini_set('session.cookie_secure', '1');
    }
    session_name('minichat_sid');
    session_start();
}

function json_response(array $data, int $status = 200): void {
    if (!headers_sent()) {
        http_response_code($status);
        header('Content-Type: application/json; charset=UTF-8');
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
